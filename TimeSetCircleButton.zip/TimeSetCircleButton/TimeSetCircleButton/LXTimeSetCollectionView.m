//
//  LXTimeSetCollectionView.m
//  MCall
//
//  Created by vsofo罗欣 on 2017/5/23.
//  Copyright © 2017年 kmw. All rights reserved.
//

#import "LXTimeSetCollectionView.h"
#import "TimeSetCollectionViewCell.h"

@implementation LXTimeSetCollectionView





/**
 重写触控响应

 @param touches
 @param event
 */
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{

    UITouch *touch = [touches anyObject];
    
    CGPoint touchPoint = [touch locationInView:self];
    
    NSIndexPath *indexPathNow = [self indexPathForItemAtPoint:touchPoint];
    
    UICollectionViewCell *aa = [self cellForItemAtIndexPath:indexPathNow];

    if ([aa isKindOfClass:[TimeSetCollectionViewCell class]]) {
        
        
        TimeSetCollectionViewCell *bb = (TimeSetCollectionViewCell *)aa;
        
//        bb.TimeBtn.selected = !bb.TimeBtn.selected;
        
        [bb.TimeBtn sendActionsForControlEvents:UIControlEventTouchUpInside];
        

        
    }
    
  
    
    [super touchesMoved:touches withEvent:event];
    
    
}

@end
