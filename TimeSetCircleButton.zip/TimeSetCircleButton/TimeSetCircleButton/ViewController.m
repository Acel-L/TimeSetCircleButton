//
//  ViewController.m
//  TimeSetCircleButton
//
//  Created by 罗欣 on 2017/7/7.
//  Copyright © 2017年 罗欣. All rights reserved.
//
#define UIColorFrom16RGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define TextPinkColor UIColorFrom16RGB(0xFF7690)
#define NorFontName @"PingFangSC-Regular"
#define FONTWITH(FONTNAME,FONTSIZE)  [UIFont fontWithName:FONTNAME size:FONTSIZE]
#define ScreenWidth [[UIScreen mainScreen] bounds].size.width
#define ScreenHeight [[UIScreen mainScreen] bounds].size.height

#define GetImage(imageName) [UIImage imageNamed:[NSString stringWithFormat:@"%@",imageName]]


#import "ViewController.h"
#import "LXTimeSetCollectionView.h"

#import "CircleLayout.h"
#import "TimeSetCollectionViewCell.h"
#import "TimeShowCollectionViewCell.h"

#import "ShowTimeModel.h"
#import "SelecTimeModel.h"

static inline float NumberValueFit(float iphone6NumberValue)
{
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        return ceil (iphone6NumberValue *320.0f/375.0f);
    }
    if ([[UIScreen mainScreen] bounds].size.height == 736) {
        return ceil (iphone6NumberValue *414.0f/375.0f);
    }
    return iphone6NumberValue;
}

@interface ViewController () <UICollectionViewDelegate,UICollectionViewDataSource,UIScrollViewDelegate>
{


    //控制器背景图
    UIImageView *_VCBackImage;
    
    
    LXTimeSetCollectionView *_circleView;
    
    UIImageView *_CenterImage;
    
    //选中时段展示列表
    //    UICollectionView *_ShowTimeSetCollectionView;
    UIScrollView  * selectedTimeScrollView;
    NSMutableArray * selectedTimeCellviewArr;
    
    //同步按钮
    UIButton *_SynchronizeBtn;
    
    //日期标题
    UILabel *_TimeTitleLabel;
    
    //设置按钮
    UIButton *_SureBtn;
    
    BOOL firstFlag; //记录是否第一次执行

}

@property (nonatomic,strong) NSMutableArray *TimeSelectArr;
@property (nonatomic,strong) UIPageControl *pageControl;
@property (nonatomic, assign)int currentIndex;

@property (nonatomic,strong) NSMutableArray *TimeSetArr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self SetUp];
}

-(void)loadView{
    [super loadView];
    UIScrollView * view = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    self.view = view;
}

/**
 数据更新
 */
- (void)ReloadSelectData
{
    
    
    
    [_TimeSelectArr removeAllObjects];
    
    NSString *str = @"";
    for (int i = 0; i < _TimeSetArr.count; i ++) {
        
        ShowTimeModel *model = _TimeSetArr[i];
        
        if (model.IsSelect) {
            
            
            if (str.length) {
                
                
            }else
            {
                
                str =  [str stringByAppendingString:[NSString stringWithFormat:@"%ld:00",(long)model.TimeNum]];
                
            }
            
            
            if (i == _TimeSetArr.count - 1) {
                
                str =  [str stringByAppendingString:[NSString stringWithFormat:@"-%ld:00",(long)model.TimeNum + 1]];
                
                [_TimeSelectArr addObject:str];
                
            }
            
            
            
            
        }else
        {
            
            if (str.length) {
                
                str =  [str stringByAppendingString:[NSString stringWithFormat:@"-%ld:00",(long)model.TimeNum]];
                
                [_TimeSelectArr addObject:str];
                str = @"";
                
            }else
            {
                
            }
            
        }
    }
    
    [selectedTimeScrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [selectedTimeCellviewArr removeAllObjects];
    
    NSInteger page = _TimeSelectArr.count / 9;
    
    if (page == 0 || _TimeSelectArr.count == 9) {
        _pageControl.hidden = YES;
        _pageControl.numberOfPages = 1;
    }else{
        
        _pageControl.hidden = NO;
        
        if (_TimeSelectArr.count % 9 == 0) {
            _pageControl.numberOfPages = page;
        }else{
            _pageControl.numberOfPages = page + 1;
        }
        self.pageControl.currentPage = 0;
    }
    
    selectedTimeScrollView.contentSize = CGSizeMake(_pageControl.numberOfPages * selectedTimeScrollView.frame.size.width ,0);
    
    if (firstFlag == YES) {
        
        NSInteger index = _pageControl.numberOfPages - 1;
        if (index < 0) {
            index = 0;
        }
        
        [UIView animateWithDuration:0.38 animations:^{
            selectedTimeScrollView.contentOffset = CGPointMake(index * selectedTimeScrollView.frame.size.width, 0);
        }];
    }
    
    firstFlag = YES;
    
    for (NSString * time in _TimeSelectArr) {
        [self addView:time];
        
    }
    
}

/**
 初始化UI
 */
- (void)SetUp
{

    self.title = @"设置通话时段";


    //控制器背景图
    _VCBackImage = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    _VCBackImage.image = GetImage(@"VoiceCard_back_image");
    
    [self.view addSubview:_VCBackImage];
    
    
    [self CreateCircleCollectionView];

    
    [self CreateShowTimeSetCollectionView];
    
    
    //时间刻度
    _CenterImage = [[UIImageView alloc] init];
    
    _CenterImage.frame = CGRectMake( _circleView.frame.origin.x + (31 + 10 ), _circleView.frame.origin.y + (31 + 10 ), _circleView.frame.size.width -  2 *(31 + 10), _circleView.frame.size.width - 2 *(31 + 10));
    
    _CenterImage.image = GetImage(@"TimeSetCenter_backImage");
    
    [self.view addSubview:_CenterImage];
    
   
}

- (void)CreateCircleCollectionView
{
    
    _TimeSetArr = [NSMutableArray array];
    _TimeSelectArr = [NSMutableArray array];
    
    
    //分割选中的时段
    NSArray *aa = @[];
    
    for (int i = 0; i < 24; i ++) {
        
        ShowTimeModel *model = [[ShowTimeModel alloc] init];
        
        model.TimeNum = i;
        
        //设置选中的时段为yes
        
        for (NSString *str in aa) {
            
            if ([str integerValue] == i && str.length) {
                
                model.IsSelect = YES;
                
            }
        }
        
        
        [_TimeSetArr addObject:model];
    }
    
    
    
    CircleLayout * layout = [[CircleLayout alloc]init];
    _circleView  = [[LXTimeSetCollectionView alloc]initWithFrame:CGRectMake(ScreenWidth / 2 - 125, 25 + 64, 250, 250) collectionViewLayout:layout];
    _circleView.delegate=self;
    _circleView.dataSource=self;
    _circleView.backgroundColor = [UIColor clearColor];
    
    [_circleView registerNib:[UINib nibWithNibName:@"TimeSetCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"Cell"];
    [self.view addSubview:_circleView];
    
    
    
    
}

- (void)CreateShowTimeSetCollectionView
{
    
    UICollectionViewFlowLayout * layout2 = [[UICollectionViewFlowLayout alloc] init];
    layout2.minimumLineSpacing = 8 ;
    layout2.sectionInset = UIEdgeInsetsMake(5, 5 , 5 , 5 );
    layout2.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    
    CGFloat height = 0;
    
    height =NumberValueFit(140);
    
    
    
    selectedTimeScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_circleView.frame) + NumberValueFit(15), ScreenWidth , height)];
    selectedTimeScrollView.showsHorizontalScrollIndicator = NO;
    selectedTimeScrollView.delegate = self;
    [self.view addSubview:selectedTimeScrollView];
    selectedTimeScrollView.pagingEnabled = YES;
    
    self.pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(ScreenWidth/2 - 40, CGRectGetMaxY(selectedTimeScrollView.frame) , 80, 20)];
    
    self.pageControl.contentHorizontalAlignment = UIControlContentHorizontalAlignmentFill;
    //    self.pageControl.numberOfPages = 1;
    //    if(_TimeSelectArr.count == 0){
    //        self.pageControl.alpha = 0;
    //    }
    self.pageControl.currentPage = 0;
    self.pageControl.pageIndicatorTintColor = [UIColor lightTextColor];
    self.pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
    [self.view addSubview:self.pageControl];
    
  
    //更新数据
    [self ReloadSelectData];
}



//添加一个cell
-(void)addView:(NSString *)time{
    
    if (selectedTimeCellviewArr == nil) {
        selectedTimeCellviewArr = [NSMutableArray array];
    }
    
    SelecTimeModel * model = [[SelecTimeModel alloc]init];
    model.time = time;
    
    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0,NumberValueFit(99),NumberValueFit(25))];
    label.layer.cornerRadius = NumberValueFit(25) / 2.0;
    label.layer.masksToBounds = YES;
    label.textAlignment = NSTextAlignmentCenter;
    label.backgroundColor = [UIColor whiteColor];
    label.text = time;
    label.textColor = TextPinkColor;
    label.font = FONTWITH(NorFontName, 12);
    
    model.label = label;
    model.index = selectedTimeCellviewArr.count ;
    
    [selectedTimeCellviewArr addObject:model];
    SelecTimeModel * lastModel = [selectedTimeCellviewArr lastObject];
    
    
    //view之间的间隔
    CGFloat interval_x = (ScreenWidth - 3 *  NumberValueFit(99)) / 4.0;
    CGFloat interval_y =  (selectedTimeScrollView.frame.size.height - 3 * NumberValueFit(25)) / 4.0;
    
    NSInteger index = lastModel.index;
    //页
    NSInteger page = index / 9;
    //列
    NSInteger col = index % 3;
    //行
    NSInteger row = index / 3;
    
    page = row / 3;
    if (row >=3) {
        row = row%3;
    }
    
    label.frame = CGRectMake (page *selectedTimeScrollView.frame.size.width + row * (interval_x + NumberValueFit(99)) + interval_x, col * (interval_y + NumberValueFit(25)) + interval_y, label.frame.size.width, label.frame.size.height) ;

    
    if (label.frame.origin.x > selectedTimeScrollView.contentSize.width) {
        
        selectedTimeScrollView.contentSize = CGSizeMake((page + 1)*selectedTimeScrollView.frame.size.width , 0);
        selectedTimeScrollView.contentOffset = CGPointMake(label.frame.origin.x - interval_x, 0);
    }
    
    [selectedTimeScrollView addSubview:label];
    
}

#pragma mark --UICollectionViewDelegate
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    if (collectionView == _circleView) {
        
        return 0.001f;
        
    }
    
    return NumberValueFit(20);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    if (collectionView == _circleView) {
        
        return 0.001f;
        
    }
    
    return NumberValueFit(10);
}


-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    if (collectionView == _circleView) {
        
        return _TimeSetArr.count;
        
    }
    
    return _TimeSelectArr.count;
}

// 每一个cell的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    //    if (collectionView == _ShowTimeSetCollectionView) {
    //
    //        return CGSizeMake((_ShowTimeSetCollectionView.width - 3 * (99 + 12))/ 3 + 99,25);
    ////        return CGSizeMake(198/2.0 ,25);
    //
    //    }
    //   *  50
    return CGSizeMake(28, 31);
    
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if (collectionView == _circleView) {
        
        TimeSetCollectionViewCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
        
        cell.layer.masksToBounds = YES;
        cell.SubVC = self;
        
        cell.model = _TimeSetArr[indexPath.row];
        
        return cell;
        
        
    }
    
    
    TimeShowCollectionViewCell * cell  = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    cell.TimeShowLabel.font = FONTWITH(NorFontName, 13);
    
    [cell setShowStr:_TimeSelectArr[indexPath.row]];
    
    
    return cell;
    
}


#pragma mark UIScrollViewDelegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    self.pageControl.currentPage = scrollView.contentOffset.x/selectedTimeScrollView.frame.size.width;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
