//
//  TimeShowCollectionViewCell.h
//  MCall
//
//  Created by vsofo罗欣 on 2017/5/23.
//  Copyright © 2017年 kmw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeShowCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *TimeShowLabel;
- (void)setShowStr:(NSString *)str;

@end
