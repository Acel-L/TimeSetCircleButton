//
//  ShowTimeModel.h
//  TimeSetCircleButton
//
//  Created by vsofo罗欣 on 2017/7/7.
//  Copyright © 2017年 vsofo罗欣. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShowTimeModel : NSObject

/**
 时间段数字（0 - 23）
 */
@property (nonatomic,assign) NSInteger TimeNum;


/**
 时间段是否被选中
 */
@property (nonatomic,assign) BOOL IsSelect;

@end
