//
//  CircleLayout.h
//  MCall
//
//  Created by vsofo罗欣 on 2017/5/22.
//  Copyright © 2017年 kmw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircleLayout : UICollectionViewLayout


//这个int值存储有多少个item
@property(nonatomic,assign) int itemCount;
@end
