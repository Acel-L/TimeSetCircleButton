//
//  TimeSetCollectionViewCell.m
//  MCall
//
//  Created by vsofo罗欣 on 2017/5/23.
//  Copyright © 2017年 kmw. All rights reserved.
//


#define UIColorFrom16RGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]


#import "TimeSetCollectionViewCell.h"

@interface TimeSetCollectionViewCell ()

@end
@implementation TimeSetCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.TimeBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [self.TimeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [self.TimeBtn setTitleColor:UIColorFrom16RGB(0x666666) forState:UIControlStateNormal];

    [self.TimeBtn setBackgroundImage:[UIImage imageNamed:@"TimeSet_backImage_nor"] forState:UIControlStateNormal];
    [self.TimeBtn setBackgroundImage:[UIImage imageNamed:@"TimeSet_backImage_sel"] forState:UIControlStateSelected];

//    self.TimeBtn.enabled = NO;
    [self.TimeBtn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
    
//    [self.TimeBtn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchDragExit];
    
//    UISwipeGestureRecognizer *aaa = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(panAction:)];
//
//    [self.TimeBtn addGestureRecognizer:aaa];
}

- (void)setModel:(ShowTimeModel *)model
{

    _model = model;
    
    [self.TimeBtn setTitle:[NSString stringWithFormat:@"%ld",(long)model.TimeNum] forState:UIControlStateNormal];
    
    self.TimeBtn.selected = model.IsSelect;
 

}
- (void)BtnAction:(UIButton *)sender
{

    sender.selected = !sender.selected;
    
    _model.IsSelect = sender.selected;

    if (self.SubVC) {
        
        
        [self.SubVC ReloadSelectData];
    }
}

- (void)panAction:(UISwipeGestureRecognizer *)pan
{

    UIButton *aa = (UIButton *) pan.view;
    
    aa.selected = !aa.selected;


}










@end
