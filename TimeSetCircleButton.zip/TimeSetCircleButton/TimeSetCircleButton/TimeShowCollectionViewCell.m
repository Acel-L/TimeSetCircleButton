//
//  TimeShowCollectionViewCell.m
//  MCall
//
//  Created by vsofo罗欣 on 2017/5/23.
//  Copyright © 2017年 kmw. All rights reserved.
//

#import "TimeShowCollectionViewCell.h"

@interface TimeShowCollectionViewCell ()



@end
@implementation TimeShowCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.TimeShowLabel.backgroundColor = [UIColor whiteColor];
    self.TimeShowLabel.font = [UIFont systemFontOfSize:13];
    self.TimeShowLabel.textColor = [UIColor redColor];
    
}

- (void)setShowStr:(NSString *)str
{

    self.TimeShowLabel.text = str;

}

- (void)layoutSubviews
{

    [super layoutSubviews];
    
    self.TimeShowLabel.layer.cornerRadius = self.TimeShowLabel.frame.size.height / 2;
    


}

@end
