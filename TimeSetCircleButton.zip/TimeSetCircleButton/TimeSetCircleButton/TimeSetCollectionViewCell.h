//
//  TimeSetCollectionViewCell.h
//  MCall
//
//  Created by vsofo罗欣 on 2017/5/23.
//  Copyright © 2017年 kmw. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ShowTimeModel.h"

#import "ViewController.h"

@interface TimeSetCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIButton *TimeBtn;
@property (strong, nonatomic) ViewController *SubVC;


@property (nonatomic,strong) ShowTimeModel *model;
@end
