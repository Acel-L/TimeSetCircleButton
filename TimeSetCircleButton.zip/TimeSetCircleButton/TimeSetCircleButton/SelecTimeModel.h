//
//  SelecTimeModel.h
//  TimeSetCircleButton
//
//  Created by vsofo罗欣 on 2017/7/7.
//  Copyright © 2017年 vsofo罗欣. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SelecTimeModel : NSObject

/**
 时间段数字（0 - 23）
 */
@property(nonatomic,strong) UILabel * label;

@property(nonatomic,assign)NSInteger index;

@property(nonatomic,strong)NSString * time;

@end
